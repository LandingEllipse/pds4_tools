pds4_tools.utils.compat module
==============================

.. currentmodule:: pds4_tools.utils.compat

Modules
-------

 argparse

    An alias of ``argparse``.


Classes
-------

.. class:: OrderedDict

    An alias of ``collections.OrderedDict``.

Functions
---------

 .. function:: ET_Element

    An alias of ``xml.etree.ElementTree.Element``.

 .. function:: ET_Tree_iter

    An alias of ``xml.etree.ElementTree.iter``.

 .. function:: ET_Element_iter

    An alias of ``xml.etree.ElementTree.Element.iter``.

 .. function:: ET_ParseError

    An alias of ``xml.etree.ElementTree.ParseError``.